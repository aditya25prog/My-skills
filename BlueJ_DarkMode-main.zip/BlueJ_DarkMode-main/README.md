# BlueJ Dark Theme

## Video explanation
[youtube](https://www.youtube.com/watch?v=4xYQRZ4VHZg)

## Installation

1. First go to `C:\Program Files\BlueJ\lib\stylesheets`
2. Select all the items in this folder and copy it to another folder for later use if you need to switch back to light mode.
3. Now clone/Download this repo and paste all the content of this repo into the same folder (\BlueJ\lib\stylesheets)
4. Close blueJ if you have it open and open it again.
5. If you run into any problems feel free to leave a comment in this [video](https://www.youtube.com/watch?v=4xYQRZ4VHZg) !

# Contact
Discord: `SoulNinja#7777`
Twitter: `@Aadhithyan_17`
